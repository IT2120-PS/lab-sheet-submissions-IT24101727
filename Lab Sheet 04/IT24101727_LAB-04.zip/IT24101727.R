getwd()
setwd("C:\\Users\\IT24101727\\Desktop\\IT24101727")


branch_data<-read.csv("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)


str(branch_data)

boxplot(Sales_X1,main="Box plot for Sales",ylab="Sales",horizontal=TRUE,outline=TRUE)

summary(Advertising_X2)
quantile(Advertising_X2)
IQR(Advertising_X2)

find.outliers<-function(x){
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3-q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ",ub))
  print(paste("Lower Bound = ",lb))
  print(paste("Outliers: ",paste(sort(x[x<lb | x>ub]), collapse = " ,")))
  
}


outliers_years<-find.outliers(Years_X3)
outliers_years
