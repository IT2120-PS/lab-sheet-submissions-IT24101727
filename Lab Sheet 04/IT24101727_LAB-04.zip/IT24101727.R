getwd()
setwd("C:\\Users\\IT24101727\\Desktop\\IT24101727")


branch_data<-read.table("Exercise.txt", header = TRUE, sep = "")
fix(branch_data)
attach(branch_data)

str(branch_data)

boxplot(Sales,main="Box plot for Sales",ylab="Sales",horizontal=TRUE,outline=TRUE)

summary(Advertising, probs=(0.25,0.75))
quantile(Advertising)
IQR(Advertising)

find.outliers<-function(x){
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3-q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ",ub))
  print(paste("Lower Bound = ",lb))
  print(paste("Outliers: ",paste(sort(x[x<lb | x>ub]), collapse = " ,")))
  
}


get.outliers(Years)